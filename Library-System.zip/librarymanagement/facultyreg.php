<!--FACUTLY-->
<?php
include("connection.php");
?>
<?php
  if(isset($_POST['submit1']))
  {
    $f_name=$_POST['f_name'];
    $f_id=$_POST['f_id'];
    $f_mobile=$_POST['f_mobile'];
    $f_email=$_POST['f_email'];
    $pass=$_POST['f_pass'];

     //Encryption pasword
      $mdpass=md5($pass);
      $f_pass=sha1($mdpass);

    $un=mysqli_query($db,"SELECT * FROM `faculty` where faculty_name='$f_name'");
    $en=mysqli_query($db,"SELECT * FROM `faculty` where f_id='$f_id'");
    $em=mysqli_query($db,"SELECT * FROM `faculty` where  f_email='$f_mobile'");
    $mo=mysqli_query($db,"SELECT * FROM `faculty` where f_mobile='$f_email'"); 

    //duplicate data validation
    if(mysqli_num_rows($un)> 0)
    {
     $name_err="* Username is already used";
    }
    //duplicate data validation
    elseif(mysqli_num_rows($en)> 0)
    {
     $id_err="* ID is already used";
    }
    //duplicate  data validation
     elseif(mysqli_num_rows($em)> 0)
    {
     $email_err="* Email id is already used";
    }
    //duplicate  data validation
    elseif(mysqli_num_rows($mo)> 0)
    {
     $mobile_err="* Mobile number is already used";
    }
    //Username String validation
      elseif(!preg_match('/^[a-zA-Z\s]+$/',$f_name))
      {
        $name_err="* Please enter name as only string";
      }
   
    else
    {

    mysqli_query($db,"INSERT INTO faculty values('','$f_name','$f_id','$f_email','$f_pass','$f_mobile','$_POST[f_dept]','no')");

$sub = "Mail from GPWLibrary";
//the messageu
$msg = "Thanks for Registraion GPW Library Please Wait Librarin Accept Request after you can login and use";
//recipient email here
$rec = $f_email;
//send email
mail($rec,$sub,$msg);
    ?>
    <script type="text/javascript">
      alert("Registration Successful...");
      window.location="facultyreg.php";
    </script>
    <?php

  }
}
  ?>
<!DOCTYPE html>
<html>
<head>
  <title>Faculty Registration</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!--Icon-->
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

.sidenav {
  margin-top: 130px;
  height:  844px;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
  margin-top: px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
/* Style The Dropdown Button */
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border-radius: 5%;
  cursor: pointer;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #333;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  margin-left: 10px;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: black;}
/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {color: #f1f1f1;}

.form-control
{
  margin-left: -5px;
}
</style>
</head>
<body>

 <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a><br><br><br>
  <a href="index.php"><span class="glyphicon glyphicon-home"> Home</span></a><br>
  <a href="a_book.php"> <span class="glyphicon glyphicon-book"> Search Book</span></a><br>
  <div class="dropdown">
  <a style=" font-size:25px;" ><span class="glyphicon glyphicon-log-in"> Sign Up</span></a>
  <div class="dropdown-content">
     <a href="staffregister.php">Staff</a>
    <a href="user_reg.php">Student</a>
  </div>
</div><br>
   <div class="dropdown">
  <a  style=" font-size:25px;"><span class="glyphicon glyphicon-user"> Sign In</span></a>
  <div class="dropdown-content">
    <a href="adminlogin.php">Admin</a>
    <a href="stafflogin.php">Staff</a>
    <a href="facultylogin.php">Faculty</a>
    <a href="st_login.php">Student</a>
  </div>
</div><br>
  <!--<a href="adminlogin.php"> <span class="glyphicon glyphicon-log-in"> Login</span></a>
  <a href="user_reg.php"> <span class="glyphicon glyphicon-user"> NewUser</span></a>
  -->
  <a href="#"><span class="glyphicon glyphicon-about"> About</span></a><br>
  <a href="#">Contact Us</a>
</div>
<header>
   <?php
   include "header.php";
   ?>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>


<script>

 <?php
   include "script.php";
   ?>
 
</script>
<section>
 
   <div class="box2">
 <div class="header">
  Faculty Sign up </div>
    <form name="register" action="" method="POST" onsubmit="return validation()">

        <input class="form-control" type="text" name="f_name" id="f_name" placeholder="Enter Faculty Name" autocomplete="off" required pattern="[a-zA-Z\s].{2,}" value="<?php if(isset($f_name)){ echo $f_name;} ?>">
        <i class="far fa-user"></i>
        <span class="error"><?php if(isset($name_err)){echo $name_err;} ?></span>
        <br><br>

        <input class="form-control" type="text" name="f_id" id="f_id" placeholder="Enter Faculty Id" autocomplete="off" required maxlength="6" pattern="[0-9]{6}" title="Enate valid Id" value="<?php if(isset($f_id)){ echo $f_id;} ?>" >
        <i class="far fa-id-card"></i>
        <span class="error"><?php if(isset($id_err)){echo $id_err;} ?></span>
        <br><br>
    
      <input class="form-control" type="email" name="f_email" id="f_email" placeholder="Enter Email id" autocomplete="off"required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="<?php if(isset($f_email)){ echo $f_email;} ?>" >
      <i class="far fa-envelope"></i>
      <span class="error"><?php if(isset($email_err)){echo $email_err;} ?></span>
      <br><br>

      <input class="form-control" type="password" name="f_pass" id="pswrd" placeholder="Password must be 8 characters or more" autocomplete="off" required pattern=".{8,}" title="Password must be 8 characters or more" value="<?php if(isset($pass)){ echo $pass;} ?>">
      <i class="fas fa-lock" onclick="show()"></i>
      <span class="error"><?php if(isset($pass_err)){echo $pass_err;} ?></span>
      <br><br>
      
     <input class="form-control" type="text" maxlength="10" name="f_mobile" id="f_mobile" placeholder="Enter mobile number" required pattern="[6789][0-9]{9}" autocomplete="off" value="<?php if(isset($f_mobile)){ echo $f_mobile;} ?>" >
     <i class="fa fa-phone"></i>
     <span class="error"><?php if(isset($mobile_err)){echo $mobile_err;} ?></span>
     <br><br>

       <select name="f_dept" class="form-control" required>
        <option disabled selected value>Select Department</option>
        <option>Computer</option>
        <option>Civil</option>
        <option>Mechanical</option>
       </select>
        <br><br><br>
       <input type="submit" name="submit1" value="Sign Up">
    </form>
    
  </div>
  </div>
</section>

 
</div>
</div>
<?php
include "footer2.php";
?>
<script>
  function show() {
    var pswrd=document.getElementById('pswrd');
    var icon=document.querySelector('.fas');
    if(pswrd.type=="password")
    {
        pswrd.type="text";
        icon.style.color="#5c1769";
    }
    else
    {
        pswrd.type="password";
        icon.style.color="grey";
    }
  }
</script>
</body>
</html>