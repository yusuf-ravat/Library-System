<?php
session_start();
if (isset($_SESSION['faculty']))
{
	unset($_SESSION['faculty']);
}
header("location:index.php");
?>