<?php
session_start();
if(!isset($_SESSION['admin']))
{
  ?>
      <script type="text/javascript">
        window.location="adminlogin.php";
      </script>
  <?php
}
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Issue Book</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}
.srch
{
  margin-left: 200px;
}

.sidenav {
  margin-top: 130px;
  height: 141.5%;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
  margin-top: px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

  
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="index.php">Home</a>
  <a href="student_info.php">All Student Info</a>  
   <a href="a_book.php">Book</a>
 <a href="addbook.php">Add Book</a> 
 <a href="return.php">Return Book</a>
  <a href="student_book_details.php">Studnt Book Info</a>
<a href=" send_notification_student.php ">Send Notification</a>
  <a href="#">About</a>
  <a href="#">Contact Us</a>
  <a href="logout.php">Logout</a>
</div>
<header>
    <img src="download.png" height="120px" width="120px" class="img">
    <h1 class="h" style= "font-family: Lato sans-serif text-align :center" ;   >Library Management System Government Polytechnic Waghai </h1>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>


<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "white";
}
</script>
<h2>Issue Book</h2>
  <div class="srch">
    <form class="navbar-form" method="POST" name="form1">
      
     <table>
       <tr>
          <td>
            <select class="form-control selectpicker" name="s_eno">
              <?php
              $res=mysqli_query($db,"SELECT s_enroll from student");
              while ($row=mysqli_fetch_array($res)) 
              {
                echo "<option>";
                echo $row["s_enroll"];
                echo "</option>";
              }
              ?>
            </select>
          </td>
          <td>
            <input type="submit" name="submit1" value="search" class="form-control btn btn-default" style="margin-left:10px;">
          </td>
       </tr>
     </table>
    </form>
    <?php
    if(isset($_POST['submit1']))
    {
      $res5=mysqli_query($db,"SELECT * from student where s_enroll='$_POST[s_eno]'");
       while ($row5=mysqli_fetch_array($res5)) 
      {
        $firstname=$row5["firstname"];
        $lastname=$row5["lastname"];
        $username=$row5["username"];
        $s_enroll=$row5["s_enroll"];
        $s_email=$row5["s_email"];
        $s_mobile=$row5["s_mobile"];
        $s_dept=$row5["s_dept"];
        $s_sem=$row5["s_sem"];
        $_SESSION["s_enroll"]=$s_enroll;
        $_SESSION["susername"]=$username;


      }
      ?>
      <form action="" method="POST">
            <table class="table table-bordered">
              <tr>
                <td>
                <input class="form-control" type="text" name="enroll" value="<?php echo $s_enroll; ?>" placeholder="Student Enrolment" disabled>
                </td>
              </tr>

              <tr>
                <td>
                <input class="form-control" type="text" name="name" value="<?php echo $firstname.' '.$lastname; ?>" placeholder="Student Name" required>
                </td>
              </tr>

               <tr>
                <td>
                <input class="form-control" type="text" name="dept" value="<?php echo $s_dept; ?>" placeholder="Student Department" required>
                </td>
                 </tr>

                <tr>
                <td>
                <input class="form-control" type="text" name="sem" value="<?php echo $s_sem; ?>" placeholder="Student Sem" required>
                </td>
              </tr>

               <tr>
                <td>
                <input class="form-control" type="text" name="con" value="<?php echo $s_mobile; ?>" placeholder="Student Contect" required>
                </td>
              </tr>
               <tr>
                <td>
                <input class="form-control" type="text" name="email" value="<?php echo $s_email; ?>" placeholder="Student Email" required>
                </td>
              </tr>

              <tr>
                <td>
                  <select name="bookname" class="form-control selectpicker">
                    <?php
                    $res=mysqli_query($db,"SELECT b_name from add_book");
                     while ($row=mysqli_fetch_array($res)) 
                     {
                      echo "<option>";
                      echo $row["b_name"];
                      echo "</option>";
                     }
                    ?>
                    
                  </select>
                </td>
              </tr>

               <tr>
                <td>
                <input class="form-control" type="text" value="<?php echo date("d-m-y"); ?>" name="bookissuedate" placeholder="Book issuedate" required>
                </td>
              </tr>
               <tr>
                <td>
                <input class="form-control" type="text" name="username" value="<?php echo $username; ?>"  placeholder="Student Username" disable>
                </td>
              </tr>

               <tr>
                <td>
                  <form action="" method="POST">
                <input class="form-control" type="submit" name="submit2" class="form-control btn btn-default" value="issue book" style="background-color: blue; color: white;">
              </form>
                </td>
              </tr>  
            </table>
            </form>
      <?php
    }
    ?>

    <?php
    if(isset($_POST['submit2']))
    {
      $qty=0;
      $res=mysqli_query($db,"SELECT * from add_book where b_name= '$_POST[bookname]'");
      while($row=mysqli_fetch_array($res))
      {
          $qty=$row["avilable"];
      }
      if($qty==0)
      {
          ?>
          <script type="text/javascript">
            alert("This book are not available in stock.." );
          </script>
          <?php
      }
      else
      {
      mysqli_query($db,"INSERT INTO issue_book values ('','$_POST[s_enroll]','$_POST[name]','$_POST[dept]','$_POST[sem]','$_POST[con]','$_POST[email]','$_POST[bookname]','$_POST[bookissuedate]','','$_SESSION[susername]')");

        mysqli_query($db,"UPDATE add_book set  avilable=avilable-1 where b_name='$_POST[bookname]'");
      ?>
      <script type="text/javascript">
        alert("Issue Book succeesful");
        window.location.href= window.location.href;
      </script>
      <?php
        }
    }
    ?>
  </div>
<section>

 
  <?php
  
    ?>  

</section>
     </div>
  </div>
  </div>
    <?php
include "footer2.php";
?>
</body>
</html>