<?php
include "connection.php";
$id=$_GET["id"];
$email=$_GET["email"];
mysqli_query($db,"UPDATE student SET status='No' where id=$id");
$sub = "Mail From Government Polytecnic Collage Waghai..Libraya";
//the messageu
$msg = "Dear Student Your Request has not Approve becaus your identity is wrong ";
//recipient email here
$rec =$email;
//send email
mail($rec,$sub,$msg);
?>
<script type="text/javascript">
	window.location="student_info.php";
</script>