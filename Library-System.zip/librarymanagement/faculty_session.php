
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.sesion
		{
			color:white;
			font-family: Century;
			font-size: 17px;
			padding: 10px;
		}
	</style>
</head>
<body>

<?php
echo "<div class=sesion>";
$q=mysqli_query($db,"SELECT * from faculty where f_id='$_SESSION[faculty]'");

 $row=mysqli_fetch_assoc($q);
 
   echo "<b>Name:</b>&nbsp&nbsp"
                    .$row['faculty_name']."<br>";

   echo "<b>Id:</b>&nbsp&nbsp"
                   .$row['f_id']."<br>";
echo "</div>";
  ?>
  </body>
</html>