<!DOCTYPE html>
<html>
<head>
	<title></title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style type="text/css">
	footer
{
   height: 150px;
    width: 1387px;
    margin-top: -130px;
    background-color: #333;
}
	.fa
	{
		margin: 0px 5px;
		padding: 5px;
		font-size: 20px;
		width: 20px;
		height: 20px;
		text-align: center;
		text-decoration: none;
		border-radius: 50%;
	}
	.fa:hover
	{
		opacity: .7;
	}
	.fa-facebook
	{
		margin-left: 30px;
		background:#3B5998;
		color:white; 
	}
		
	.fa-twitter
	{
		background:#55ACEE;
		color:white; 
	}	
	.fa-google
	{
		background:#dd4b39;
		color:white; 
	}	
     .fa-instagram
	{
		background:#125688;
		color:white; 
	}
	.fa-yahoo
	{
		background:#400297;
		color:white; 
	}

</style>
</head>	
<body>
	<footer style="background-color:#333;">
		<h3 style="color: white; text-align: center;"> Contact us</h3><br>
		<div style="margin:0px 570px;">
		<a href="#" class="fa fa-facebook"></a>
		<a href="#" class="fa fa-twitter"></a>
		<a href="#" class="fa fa-google"></a>
		<a href="#" class="fa fa-instagram"></a>
		<a href="#" class="fa fa-yahoo"></a>
	</div>
		<br>

		<p style="color: white; text-align: center;">
			Email : Library@yahoo.com<br><br>
		    Mobile No: &nbsp +919878653320
	</p>
	</footer>
</body>
</html>