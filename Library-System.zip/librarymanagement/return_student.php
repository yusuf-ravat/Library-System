<!--LIBRARIAN STUDENT RETURN-->
<?php
session_start();
include "connection.php";

$id=$_GET["id"];
$sno=$_GET["seno"];

$b_id="";
$seno="";
$res=mysqli_query($db,"SELECT * from issue_book where b_id=$id AND seno=$sno");

while ( $row=mysqli_fetch_array($res)) 
{
	$b_id=$row["b_id"];
	$seno=$row["seno"];

}
$d=date("Y-m-d");
mysqli_query($db,"UPDATE add_book set  avilable=avilable+1 where b_id='$id'");
mysqli_query($db,"UPDATE issue_book set status='Return',returndate='$d' where b_id='$id' 		  AND seno=$sno");
mysqli_query($db,"INSERT INTO return_book (seno,b_id,status,return_date) SELECT 				seno,b_id,status,returndate FROM issue_book WHERE status='Return';");
			
mysqli_query($db,"DELETE FROM issue_book WHERE status='Return'");



    ?>
    <script type="text/javascript">
      alert("Return Book Successfull");
      window.location="return_book_student.php";
    </script>
<?php