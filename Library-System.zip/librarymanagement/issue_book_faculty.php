<!--LIBRARIAN  FACULTY ISSUE BOOK-->
<?php
session_start();
include "connection.php";

$id=$_GET["id"];
$fid=$_GET["fid"];


$b_id="";
$faculty_id="";

$res=mysqli_query($db,"SELECT * from faculty_issue where b_id=$id AND faculty_id=$fid");
while ($row=mysqli_fetch_assoc($res)) 
{
	$b_id=$row["b_id"];
	$faculty_id=$row["faculty_id"];
}
      mysqli_query($db,"UPDATE faculty_issue set issuedate =curdate(), returndate =date_add(issuedate,interval 20 day), status ='Apply' where b_id=$id AND faculty_id=$fid");
        //mysqli_query($db,"UPDATE add_book set  avilable=avilable-1 where b_id=$id");

      

         ?>
    <script type="text/javascript">
      alert("Issue Book Successful...");
      window.location="faculty_book_request.php";
    </script>
    <?php

 ?>