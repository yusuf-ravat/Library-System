<!--LIBRARIAN-->
<?php
?>
<!DOCTYPE html>
<html>
<head>
	<title>Library Management System</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style type="text/css">

body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
  /*background-color: rgb(0, 191,150);*/
}

.sidenav {
	margin-top: 130px;
  height:856px;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
  margin-top: 2px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #333;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  margin-left: 10px;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: black;}
/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {color: #f1f1f1;}

</style>
</head>
<body>
<!--Side navbar -->
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a><br><br><br>
  <a href="index.php"><span class="glyphicon glyphicon-home"> Home</span></a><br>
  <a href="a_book.php"> <span class="glyphicon glyphicon-search"> Search Book</span></a><br>
  <div class="dropdown">
  <a style=" font-size:25px;" ><span class="glyphicon glyphicon-log-in"> Sign Up</span></a>
  <div class="dropdown-content">
    <a href="staffregister.php">Staff</a>
    <a href="facultyreg.php">Faculty</a>
    <a href="user_reg.php">Student</a>
  </div>
</div><br><br>
   <div class="dropdown">
  <a  style=" font-size:25px;"><span class="glyphicon glyphicon-user"> Sign In</span></a><br>
  <div class="dropdown-content">
    <a href="adminlogin.php">Admin</a>
    <a href="stafflogin.php">Staff</a>
    <a href="facultylogin.php">Faculty</a>
    <a href="st_login.php">Student</a>
  </div>
</div><br>

  <a href="#"><span class="glyphicon glyphicon-briefcase"> About</span></a><br>
  <a href="#"><span class="glyphicon glyphicon-new-window"> Contact Us</span></a>
</div>
<header>
   <?php
   include "header.php";
   ?>
      </header>
	<div id="main">
  
  <span style="font-size:30px;cursor:pointer; color:black;" onclick="openNav()">&#9776; Open</span>


<script>
 <?php
   include "script.php";
   ?>
</script>

<section>

	<div class="sec_img">
	<br>
	<div class="box">
		<br><br>
		<h1 style="text-align: center; font-size: 35px;">Welcome to Library</h1><br>
		<h1 style="text-align: center; font-size: 20px;">Open at 11:00 am</h1><br>
		<h1 style="text-align: center; font-size: 20px;">Close at 5:00 pm</h1><br>
	</div>

	</div>

</section>
</div>
</div>
<?php
include "footer2.php";
?>
</body>
</html>