<!--STAFF-->
<?php
include("connection.php");
?>
<?php

  if(isset($_POST['submit1']))
  {
      $id=$_POST['st_id'];
      $name=$_POST['name'];
      $s_email=$_POST['s_email'];
      $mobile=$_POST['mobile'];
      $s_pass=$_POST['s_pass'];

      //Encryption Password
      $mpass=md5($s_pass);
      $pass=sha1($mpass);

    $runname=mysqli_query($db,"SELECT * FROM staff where name='$name'"); 
    $runid=mysqli_query($db,"SELECT * FROM staff where staff_id='$id'");
    $runemail=mysqli_query($db,"SELECT * FROM staff where email='$s_email'");  
    $runmobile=mysqli_query($db,"SELECT * FROM staff where mobile_no='$mobile'"); 

    if(mysqli_num_rows($runname)>0)
    {
      $name_err="* Username is already used";
    }
    else if(mysqli_num_rows($runid)> 0)
    {
       $id_err="* Id is already used";
    }
     else if(mysqli_num_rows($runemail)> 0)
    {
       $email_err="* Email is already used";
    }
     else if(mysqli_num_rows($runmobile)> 0)
    {
       $mobile_err="* Mobile is already used";
    }
    elseif (!preg_match('/^[a-zA-Z\s]+$/', $name))
    {
     $name_err="* Please enter name as only string"; 
    }
    else
    {
      mysqli_query($db,"INSERT INTO staff values('','$name','$id','$s_email','$mobile','$pass')");
//the subject
$sub = "Mail from GPWLibrary";
//the messageu
$msg = "Thanks for Registraion GPW Library Please Wait Librarin Accept Request after you can login and use";
//recipient email here
$rec = $s_email;
//send email
mail($rec,$sub,$msg);

?>
    ?>
    <script type="text/javascript">
      alert("Registration Successful...");
      window.location="staffregister.php";
    </script>
    <?php
  }
}
  ?>
<!DOCTYPE html>
<html>
<head>
  <title>Staff Registration</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!--Icon-->
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">


body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}

.sidenav {
  margin-top: 130px;
  height: 844px;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
  margin-top: px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #333;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  margin-left: 10px;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: black;}
/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {color: #f1f1f1;}
.dropdown-button
{
  color: black;
}
.box3
{
 height: 500px;
width: 500px;
background-color: rgb(0, 19, 80);
color: white;
border-radius: 10px;
margin: 60px auto;
margin-top: 5px;
}
form .register{
    margin: auto 70px ;
}
  
</style>
</head>
<body>
 <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a><br><br><br>
  <a href="index.php"><span class="glyphicon glyphicon-home"> Home</span></a><br>
  <a href="a_book.php"> <span class="glyphicon glyphicon-book"> Search Book</span></a><br>
  <div class="dropdown">
  <a style=" font-size:25px;" ><span class="glyphicon glyphicon-log-in"> Sign Up</span></a>
  <div class="dropdown-content">
    <a href="facultyreg.php">Faculty</a>
    <a href="user_reg.php">Student</a>
  </div>
</div><br>
   <div class="dropdown">
  <a  style=" font-size:25px;"><span class="glyphicon glyphicon-user"> Sign In</span></a>
  <div class="dropdown-content">
    <a href="adminlogin.php">Admin</a>
    <a href="stafflogin.php">Staff</a>
    <a href="facultylogin.php">Faculty</a>
    <a href="st_login.php">Student</a>
  </div>
</div><br>
  <!--<a href="adminlogin.php"> <span class="glyphicon glyphicon-log-in"> Login</span></a>
  <a href="user_reg.php"> <span class="glyphicon glyphicon-user"> NewUser</span></a>
  -->
  <a href="#"><span class="glyphicon glyphicon-about"> About</span></a><br>
  <a href="#">Contact Us</a>
</div>
<header>
    <?php
   include "header.php";
   ?>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>

<script>


 <?php
   include "script.php";
   ?>
</script>

<section>
 
  <div class="box2">
 <div class="header">
Staff Sign up </div>
    <!--<h1 style="text-align: center; font-size: 25px; font-family: Algerian; color: white;">Staff Registration</h1><br><br>-->
    <form name="register" action=" " method="POST">

      <input class="form-control" type="text" name="name" placeholder="Enter Staff Name" autocomplete="off" required pattern="[a-zA-Z\s].{2,}" title="Enter valide Username" value="<?php if(isset($name)){ echo $name;} ?>">
      <i class="far fa-user"></i>
      <span class="error"><?php if(isset($name_err)){ echo $name_err;} ?></span>
      <br><br>

      <input class="form-control" type="text" name="st_id"  placeholder="Enter Id" autocomplete="off" required maxlength="6" pattern="[0-9]{6}" title="Enetr valid id" value="<?php if(isset($id)){ echo $id;} ?>">
      <i class="far fa-id-card"></i>
      <span class="error"><?php if(isset($id_err)){ echo $id_err;} ?></span>
      <br><br>

      <input class="form-control" type="email" name="s_email" placeholder="Enter Email id" autocomplete="off" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="Enter valid Email" value="<?php if(isset($s_email)){ echo $s_email;} ?>">
      <i class="far fa-envelope"></i>
      <span class="error"><?php if(isset($email_err)){ echo $email_err;} ?></span>
      <br><br>

      <input class="form-control" type="password" name="s_pass" id="pswrd" placeholder="Enter Password more than 8" autocomplete="off" required pattern=".{8,}" title="Password must be 8 characters or more" value="<?php if(isset($s_pass)){echo $s_pass;} ?>">
      <i class="fas fa-lock" onclick="show()"></i>
    <br><br>

      <input class="form-control" type="text" name="mobile" maxlength="10" placeholder="Enter mobile number" autocomplete="off" required pattern="[6987][0-9]{9}" value="<?php if(isset($mobile)){ echo $mobile;} ?>">
      <i class="fa fa-phone"></i>
      <span class="error"><?php if(isset($mobile_err)){ echo $mobile_err;} ?></span>
      <br><br>
    <input type="submit" name="submit1" value="Sign Up">
    </form>
  </div>
</section>

  </div>
  
</div>
</div>
<?php
include "footer2.php";
?>
<script>
  function show() {
    var pswrd=document.getElementById('pswrd');
    var icon=document.querySelector('.fas');
    if(pswrd.type=="password")
    {
      pswrd.type="text";
      icon.style.color="#5c1769";
    }
    else
    {
      pswrd.type="password";
      icon.style.color="grey";
    }
  }
</script>
</body>
</html>