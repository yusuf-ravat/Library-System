<?php
session_start();
if(!isset($_SESSION['admin']))
{
  ?>
      <script type="text/javascript">
        window.location="adminlogin.php";
      </script>
  <?php
}
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Send Notification</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}
.srch
{
  margin-left: 200px;
}

.sidenav {
  margin-top: 130px;
  height: 121.5%;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
  margin-top: px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

  
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="index.php">Home</a>
   <a href="student_info.php">All Student Info</a> 
   <a href="a_book.php">Book</a> 
 <a href="addbook.php">Add Book</a> 
 <a href="issue_book.php">Issue Book</a>  
<a href="return.php">Return Book</a>
  <a href="#">About</a>
  <a href="#">Contact Us</a>
  <a href="logout.php">Logout</a>
</div>
<header>
    <img src="download.png" height="120px" width="120px" class="img">
    <h1 class="h" style= "font-family: Lato sans-serif text-align :center" ;   >Library Management System Government Polytechnic Waghai </h1>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>


<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "white";
}
</script>
<h2> Send Message To Student</h2>
<form name="form1" method="POST" action="">
  <table class="table table-bordered">
    <tr>
      <td>
        <select class="form-control" name="dusername">
          <?php
              $res=mysqli_query($db,"SELECT * FROM student");
              while($row=mysqli_fetch_array($res))
              {
                  ?><option value=" <?php
                       echo $row["username"]?>">
                    <?php
                       echo $row["username"]."(".$row["s_enroll"] .")";
                    ?>
                  </option><?php
              }
          ?>
          
        </select>
      </td>
    </tr>     
    <tr>
        <td><input type="text" name="title" placeholder="Enetr title" class="form-control"></td>
    </tr>

     <tr>
        <td>
          Message<br>
          <textarea name="msg" class="form-control">
          </textarea>
        </td>
    </tr>
    <tr>
      <td><input type="submit" name="submit1" value="Send Message">
      </td>
    </tr>
  </table>  
</form>
</div>
<?php
  if(isset($_POST['submit1']))
  {
    mysqli_query($db,"INSERT INTO messages values('','$_SESSION[admin]','$_POST[dusername]','$_POST[title]','$_POST[msg]','n') ");
    ?>
    <script type="text/javascript">
      alert("Message Send Successfuly..")
    </script>
    <?php
  }
?>
<section>

 
  <?php
  
    ?>  

</section>
     </div>
  </div>
  </div>
    <?php
include "footer.php";
?>
</body>
</html>