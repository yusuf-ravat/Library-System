<!--LIBRARIAN DELETE Student-->
<?php
session_start();
include "connection.php";

$id=$_GET["id"];
$email=$_GET["email"];

      mysqli_query($db,"DELETE FROM student where id='$id'");
$sub = "Mail From Government Polytecnic Collage Waghai..Libraya";
//the messageu
$msg = "Dear Student Delete your account because you are not eligible ";
//recipient email here
$rec =$email;
//send email
mail($rec,$sub,$msg);

         ?>
    <script type="text/javascript">
      alert("Delete User Successfull");
      window.location="student_info.php";
    </script>
    <?php

 ?>