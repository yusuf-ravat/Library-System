<!--LIBRAIND DORPDOWN RETURN BOOK-->
<!DOCTYPE html>
<html>
<head>
<style>
.dropbtn {
  background-color: #5b285e;
  color: white;
  padding: 10px;
  font-size: 16px;
  border: 2px color:white;
  border-radius: 3px;
  cursor: pointer;

}

.dropdown {
  position: absolute;
  display: inline-block;
   margin-left: 390px;
   margin-top: -5px;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 15px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
  background-color: #5b285e;
  color: white;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #5b285e;
  padding: 13px;
}</style>
</head>
<body>

<h2></h2>
<div class="dropdown">
  <button class="dropbtn">Select Type</button>
  <div class="dropdown-content">
  <a href="return_book_student.php">Student Return book</a>
  <a href="return_book_faculty.php">Faculty Return book</a>
  </div>
</div>

</body>
</html>
