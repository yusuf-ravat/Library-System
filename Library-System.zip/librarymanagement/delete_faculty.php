<!--LIBRARIAN DELETE Faculty-->
<?php
session_start();
include "connection.php";

$id=$_GET["id"];
$email=$_GET["email"];

mysqli_query($db,"DELETE FROM faculty where id='$id'");
$sub = "Mail From Government Polytecnic Collage Waghai..Libraya";
//the messageu
$msg = "Sorry your behaviour arw wrong you delete this system";
//recipient email here
$rec =$email;
//send email
mail($rec,$sub,$msg);

         ?>
    <script type="text/javascript">
      alert("Delete User Successfull");
      window.location="faculty_info.php";
    </script>
    <?php

 ?>