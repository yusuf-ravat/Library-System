<!--LIBRARIAN STUDENT ISSUE BOOK-->
<?php 
session_start();
include "connection.php";

$id=$_GET["id"];
$eno=$_GET["sen"];
$b_id="";
$seno="";
$res=mysqli_query($db,"SELECT * from issue_book where b_id=$id AND seno=$eno");
while ($row=mysqli_fetch_assoc($res)) 
{
	$b_id=$row["b_id"];
	$seno=$row["seno"];
}

      mysqli_query($db,"UPDATE issue_book set issuedate =curdate(), returndate =date_add(issuedate,interval 10 day), status ='Apply' where b_id=$id AND seno=$eno");

        //mysqli_query($db,"UPDATE add_book set  avilable=avilable-1 where b_id=$id");

      

         ?>
    <script type="text/javascript">
      alert("Issue Book Successful...");
      window.location="student_book_request.php";
    </script>
    <?php

 ?>