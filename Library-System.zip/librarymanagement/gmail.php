<?php
//the subject
$sub = "Mail from yusuf";
//the messageu
$msg = "hello";
//recipient email here
$rec = "ravatsup@gmail.com";
//send email
if(mail($rec,$sub,$msg))
{
	echo "email is send";
}
else
{
	echo "emil not send";
}
?>