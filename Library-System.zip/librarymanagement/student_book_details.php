<!--LIBARIAN-->
<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Boook Details</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}
.srch
{
  margin-left: 200px;
}

.sidenav {
  margin-top: 130px;
  height: 121.5%;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
  margin-top: px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

  
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <a href="#">Home</a>
  <a href="#">All Student Info</a>  
  <a href="#">Book</a>
 <a href="#">Add Book</a> 
<a href="#">Return Book</a>   
  <a href="#">About</a>
  <a href="#">Contact Us</a>
  <a href="#">Logout</a>
</div>
<header>
    <img src="download.png" height="120px" width="120px" class="img">
    <h1 class="h" style= "font-family: Lato sans-serif text-align :center" ;   >Library Management System Government Polytechnic Waghai </h1>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>


<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "white";
}
</script>
<h2> Student Book Details</h2>
<?php

$res=mysqli_query($db,"SELECT * FROM `add_book`;");

    echo "<table class='table table-bordered table-hover' >";
      echo "<tr style='background-color: #2298ab;'>";
        //Table header
        
        echo "<th>"; echo "ID"; echo"</th>";
        echo "<th>"; echo "Book name"; echo"</th>";
        echo "<th>"; echo "Author"; echo"</th>";
        echo "<th>"; echo "Publiched"; echo"</th>";
        echo "<th>"; echo "Edition"; echo"</th>";
        echo "<th>"; echo "Page"; echo"</th>";
        echo "<th>"; echo "Copy"; echo"</th>";
        echo "<th>"; echo "Available";echo"</th>";
        echo "<th>"; echo "Price"; echo"</th>";
        echo "<th>"; echo "Department"; echo"</th>";
        echo "<th>"; echo "Semester";echo"</th>";
         echo "<th>"; echo "Student Book Record";echo"</th>";


      echo "</tr>"; 

      while($row=mysqli_fetch_assoc($res))
      {
        echo "<tr>";
            echo"<td>"; echo $row['b_id']; echo "</td>";
            echo"<td>"; echo $row['b_name']; echo "</td>";
            echo"<td>"; echo $row['b_author']; echo "</td>";
            echo"<td>"; echo $row['b_pub']; echo "</td>";
            echo"<td>"; echo $row['b_edi']; echo "</td>";
            echo"<td>"; echo $row['b_page']; echo "</td>";
            echo"<td>"; echo $row['b_copy']; echo "</td>";
            echo"<td>"; echo $row['avilable']; echo "</td>";
            echo"<td>"; echo $row['b_price']; echo "</td>";
            echo"<td>"; echo $row['b_dept']; echo "</td>";
            echo"<td>"; echo $row['b_sem']; echo "</td>";
           echo "<td>"; ?> <a href="all_student_of_this_book.php?b_id=<?php echo $row["b_id"];?>"style="color: red;">Student Book Record </a> <?php echo "</td>";
  
        echo "</tr>";
      }
    echo "</table>";  
     ?>


</div>
<section>

 
  <?php
  
    ?>  

</section>
     </div>
  </div>
  </div>
    <?php
include "footer.php";
?>
</body>
</html>