<?php
if(isset($_POST['submit']))
{
  echo $_FILES['file'];
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>

</head>
<body>

  <form method="POST" action="" enctype="multipart/form-data">
  
  	  <input type="file" name="uploadfile">
  
  		<input type="submit" name="submit" value="uploadfile">
  	</div>
  </form>
</div>
</body>
</html>