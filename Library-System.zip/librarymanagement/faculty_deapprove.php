<?php
include "connection.php";
$id=$_GET["id"];
$email=$_GET["email"];
mysqli_query($db,"UPDATE faculty SET status='no' where id=$id");
$sub = "Mail From Government Polytecnic Collage Waghai..Libraya";
//the messageu
$msg = "Dear Faculty Your Request has not approve because wrong Identity";
//recipient email here
$rec =$email;
//send email
mail($rec,$sub,$msg);
?>
<script type="text/javascript">
	window.location="faculty_info.php";
</script>