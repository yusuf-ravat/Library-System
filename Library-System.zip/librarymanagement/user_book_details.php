<!--LIBRARIAN STUDENT BOOK DETAILS-->
<?php
session_start();
include("connection.php");

if(!isset($_SESSION['admin']))
{
  ?>
      <script type="text/javascript">
        alert("Please Login First..");
        window.location="adminlogin.php";
      </script>
  <?php
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Book Details</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}
.srch
{
  margin-left: 200px;
}

.sidenav {
  margin-top: 130px;
  height: 997px;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.wrapper
      {
        padding: 10px;
        margin: -20px auto;
        width:900px;
        height: auto;
        background-color: black;
        opacity: .8;
        color: white;
      }
      .form-control
      {
        height: 70px;
        width: 60%;
      }
      .scroll
      {
        width: auto;
        height: 600px;
        overflow: auto;
      }
}
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <?php
  echo "<h3 style='color:white;font-family:Century;'>Welcome &nbsp$_SESSION[admin]</h3s>";
  ?><br><br><br>  <a href="index.php"><span class="glyphicon glyphicon-home"> Home</span></a>
  <a href="student_info.php"> <span class="glyphicon glyphicon-user"> User Approve</span>
</a>
  <a href="a_book.php"><span class="glyphicon glyphicon-search"> Book</span></a> 
 <a href="addbook.php"><span class="glyphicon glyphicon-book"> Add Book</span></a> 
    <a href="student_book_request.php"><span class="glyphicon glyphicon-registration-mark"> Book Request</span></a>
   <a href="return_book_student.php"> <span class="glyphicon glyphicon-repeat"> Return Book</span></a>
   <a href="student_issue_book_details.php"><span class="glyphicon glyphicon-check">  Issue Details </span></a>
   <a href="admin_feedback.php"><span class="glyphicon glyphicon-thumbs-up"> Review</span></a>
  <a href="#"><span class="glyphicon glyphicon-briefcase"> About</span></a>
  <a href="#"><span class="glyphicon glyphicon-new-window"> Contact Us</span></a>
  <a href="logout.php"><span class="glyphicon glyphicon-log-out"> Logout</span></a>
</div>
<header>
    <?php
    include "header.php";
    ?>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>


<script>
 <?php
    include "script.php";
    ?>
</script><br><br><br><br>
<?php
include "user_book_details_drp.php";
?>
<h2 style="font-family: Century; font-size: 35px;"><b>Student Return Book Details</h2></b><br><br>
<?php
echo "<div class =scroll>";
    if($_SESSION['admin'])
        {
          $sql="SELECT student.first_name,s_enroll,s_mobile,s_email,add_book.b_id,b_name,b_author,b_edi,b_dept,b_sem,return_book.status,return_date FROM student INNER JOIN return_book ON student.s_enroll=return_book.seno INNER JOIN add_book ON return_book.b_id=add_book.b_id WHERE return_book.status='Return'";
          $res=mysqli_query($db,$sql);


          if(mysqli_num_rows($res)==0)
          {
            echo "<h2>";
            echo "There is no user book detals";
            echo "</h2>";
          }
          else
          {
             echo "<table class='table table-bordered table-hover' >";
            echo "<tr style='background-color: #5b285e; color:white;;'>";
            //Table header
        echo "<th>"; echo "Student Name"; echo"</th>";
        echo "<th>"; echo "Enrollment"; echo"</th>";
        echo "<th>"; echo "Mobile"; echo"</th>";
        echo "<th>"; echo "Email"; echo"</th>";
        echo "<th>"; echo "Book Id"; echo"</th>";
        echo "<th>"; echo "Book Name"; echo"</th>";
        echo "<th>"; echo "Book Author"; echo"</th>";
        echo "<th>"; echo "Book Edition"; echo"</th>";
        echo "<th>"; echo "Book Department"; echo"</th>";
        echo "<th>"; echo "Book Semester"; echo"</th>";
        echo "<th>"; echo "Staus"; echo"</th>";
        echo "<th>"; echo "Return Date"; echo"</th>";

        
      echo "</tr>"; 

      while($row=mysqli_fetch_array($res))
      {
          
        echo "<tr>";
           echo"<td>"; echo $row['first_name']; echo "</td>";
            echo"<td>"; echo $row['s_enroll']; echo "</td>";
            echo"<td>"; echo $row['s_mobile']; echo "</td>";
            echo"<td>"; echo $row['s_email']; echo "</td>";
            echo"<td>"; echo $row['b_id'];echo"</td>";
            echo"<td>"; echo $row['b_name'];echo"</td>";
            echo"<td>"; echo $row['b_author'];echo"</td>";
            echo"<td>"; echo $row['b_edi'];echo"</td>";
            echo"<td>"; echo $row['b_dept'];echo"</td>";
            echo"<td>"; echo $row['b_sem'];echo"</td>";
            echo"<td>"; echo $row['status'];echo"</td>";
            echo"<td>"; echo $row['return_date'];echo"</td>";
          
           echo "</tr>";
        }
          echo "</table>";
             
        }

      }
 ?> 

</section>
  </div>
  </div>
  </div>
 
  <?php
include "footer2.php";
?>
 
</body>
</html>