<?php
session_start();
include "connection.php";
$id=$_GET["b_id"];
 mysqli_query($db,"INSERT INTO issue_book values ('$_SESSION[username]','$_GET[bid]','','','');");
?>