<!--Student-->
<?php
include("connection.php");
?>
<?php

  if(isset($_POST['submit1']))
  {

    $eno=$_POST['s_eno'];
    $name=$_POST['firstname'];
    $email=$_POST['s_email'];
    $mobile=$_POST['s_mobile'];
    $pass=$_POST['s_pass'];
    //Encryption password 
    $mdpass=md5($pass);
    $s_pass=sha1($mdpass);

    $un=mysqli_query($db,"SELECT * FROM `student` where first_name='$name'");
    $en=mysqli_query($db,"SELECT * FROM `student` where s_enroll='$eno'");
    $em=mysqli_query($db,"SELECT * FROM `student` where  s_email='$email'");
    $mo=mysqli_query($db,"SELECT * FROM `student` where s_mobile='$mobile'"); 

    //Duplicate data validation
    if(mysqli_num_rows($un)> 0)
    {
     $name_err="* Username is already used";
    }
    //Duplicate data validation
    elseif(mysqli_num_rows($en)> 0)
    {
     $eno_err="* Enrollment number is already used";
    }
    //Duplicate data validation
     elseif(mysqli_num_rows($em)> 0)
    {
     $email_err="* Email id is already used";
    }
    //Duplicate data validation
    elseif(mysqli_num_rows($mo)> 0)
    {
     $mobile_err="* Mobile number is already used";
    }
    //Useername string validation
    elseif (!preg_match('/^[a-zA-Z\s]+$/', $name))
    {
     $name_err="* Please enter name as only string"; 
    }


     else{
  mysqli_query($db,"INSERT INTO student values('','$eno','$name','$email','$mobile','$_POST[s_dept]','$_POST[s_sem]','$s_pass','No')");
       ?>
    <script type="text/javascript">
      alert("Registration Successfuly.");
      window.location="user_reg.php";
    </script>
    <?php
    
  
$sub = "Mail from GPWLibrary";
//the messageu
$msg = "Thanks for Registraion GPW Library Please Wait Librarin Accept Request after you login and use";
//recipient email here
$rec = $email;
//send email
mail($rec,$sub,$msg);
   }
  }
  

  ?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Registration</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!--Icon-->
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

 <!--Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">
</script>
<style type="text/css">


body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}

.sidenav {
  margin-top: 130px;
  height: 844px;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
  margin-top: px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #333;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  margin-left: 10px;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: black;}
/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {color: #f1f1f1;}
.dropdown-button
{
  color: black;
}

.form-control
{
  margin-left: -5px;
}
</style>

 
</head>
<body>
 <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a><br><br><br>
  <a href="index.php"><span class="glyphicon glyphicon-home"> Home</span></a><br>
  <a href="a_book.php"> <span class="glyphicon glyphicon-book"> Search Book</span></a><br>
  <div class="dropdown">
  <a style=" font-size:25px;" ><span class="glyphicon glyphicon-log-in"> Sign Up</span></a>
  <div class="dropdown-content">
    <a href="staffregister.php">Staff</a>
    <a href="facultyreg.php">Faculty</a>
  </div>
</div><br>
   <div class="dropdown">
  <a  style=" font-size:25px;"><span class="glyphicon glyphicon-user"> Sign In</span></a>
  <div class="dropdown-content">
    <a href="adminlogin.php">Admin</a>
    <a href="stafflogin.php">Staff</a>
    <a href="facultylogin.php">Faculty</a>
    <a href="st_login.php">Student</a>
  </div>
</div><br>
  <!--<a href="adminlogin.php"> <span class="glyphicon glyphicon-log-in"> Login</span></a>
  <a href="user_reg.php"> <span class="glyphicon glyphicon-user"> NewUser</span></a>
  -->
  <a href="#"><span class="glyphicon glyphicon-about"> About</span></a><br>
  <a href="#">Contact Us</a>
</div>
<header>
    <?php
   include "header.php";
   ?>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>

<script>
 <?php
   include "script.php";
   ?>
</script>

<section>

  <div class="box2">
 <div class="header">
Student Sign up </div>
    <!--<h1 style="text-align: center; font-size: 25px; font-family: Algerian; color: white;">Student Registration</h1><br><br>-->

    <form name="register" action="#" method="POST" enctype="multypart/from-data">

      <input class="form-control" type="text" name="s_eno" placeholder="Enter Enrolment Number" autocomplete="off" required maxlength="12" pattern="[123][0-9]{11}" title="Please valid Enrollment number"value="<?php if(isset($eno)){ echo $eno;}?>">
      <i class="far fa-id-card"></i>
      <span class="error"><?php if(isset($eno_err)){ echo $eno_err;} ?></span>
      <br><br>

      <input class="form-control" type="text" name="firstname" placeholder="Enter Student Name" autocomplete="off" required pattern="[a-zA-Z\s].{2,}" value="<?php if(isset($name)){ echo $name;} ?>" >
       <i class="far fa-user"></i>
     <span class="error"><?php if(isset($name_err)){ echo $name_err;} ?> </span>
      <br><br>

      <input class="form-control" type="email" name="s_email" placeholder="Enter Email id" autocomplete="off" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="<?php if(isset($email)){ echo $email;}?>">
      <i class="far fa-envelope"></i>
      <span class="error"><?php if(isset($email_err)){ echo $email_err;} ?></span>
      <br><br>

      <input class="form-control" type="text" name="s_mobile" placeholder="Enter Mobile Number" autocomplete="off" maxlength="10" pattern="[6789][0-9]{9}"  required value="<?php if(isset($mobile)){ echo $mobile;} ?>">
      <i class="fa fa-phone"></i>
      <span class="error"><?php if(isset($mobile_err)){ echo $mobile_err;} ?></span>
           <br><br>

      <input class="form-control" type="password" name="s_pass" id="pswrd" placeholder="Enter Password more than 8" autocomplete="off" pattern=".{8,}" title="Password must be 8 characters or more" required value="<?php if(isset($pass)){ echo $pass;} ?>">
      <i class="fas fa-lock" onclick="show()"></i>
      <span class="error"><?php if(isset($pass_err)){ echo $pass_err;} ?></span>
    <br><br>
       <select name="s_dept"  class="form-control" required title="Select Department" >
        <option disabled selected value> Select Department</option>
        <option >Computer</option>
        <option>Civil</option>
        <option>Mechanical</option>
       </select>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp

         
         <select name="s_sem"  class="form-control" required title="Select Demester">
          <option disabled selected value>Select Semester</option>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
        <option>6</option>
       </select><br><br><br>
    <input type="submit" name="submit1" value="Sign Up" >
    </form>
  </div>
   </div>
</section>

  </div>
  
</div>
</div>

<?php
include "footer2.php";
?>
<script>
  function show() {
    var pswrd=document.getElementById('pswrd');
    var icon=document.querySelector('.fas');
    if(pswrd.type=="password")
    {
      pswrd.type="text";
      icon.style.color="#5c1769";
    }
    else
    {
      pswrd.type="password";
      icon.style.color="grey";
    }
  }
</script>
</body>
</html>