<!--Faculty Forgotpassword-->
<?php
session_start();
include ("connection.php");
?>
<?php
include ("connection.php");
if(isset($_POST['submit']))
{
  $id=$_POST['id'];
  $email=$_POST['email'];

  $newpass=$_POST['newpass'];
   $mdpass=md5($newpass);
  $f_pass=sha1($mdpass);
  
  $res=mysqli_query($db,"SELECT * FROM `faculty` WHERE f_id='$id' AND f_email='$email'");
  $num=mysqli_fetch_array($res);

  if($num>0)
  {
    $con=mysqli_query($db,"UPDATE `faculty` set pass='$f_pass' WHERE f_id=$id AND f_email='$email'");
    ?>
    <script type="text/javascript">
      alert("Password Change Successful..")
      window.location="facultylogin.php";
    </script>
    <?php
  }

else{

    $err="Invalid! Please check Id and Email";
  }
}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Faculty Forgot Password</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!--Icon-->
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">
  section
  {
    margin-top: -20px;
  }
  body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
  /*background-color: rgb(0, 191,150);*/
}
</style>
</head>

<body>
        <?php
        include "header.php";
        ?>
<section>
  

  <div class="log_img">
  <div class="box1">
 <div class="header">
      Forgot Password </div>
    <!--<h1 style="text-align: center; font-size: 25px;font-family: Algerian;">Forgot Password </h1><br><br>-->
    <form name="login" action="" method="POST">

      <span class="error"> <?php if(isset($err)){ echo $err;} ?></span><br><br>
      <input class="form-control" type="text" name="id" placeholder="Enter Id" autocomplete="off" maxlength="12" required value="<?php if(isset($eno)){ echo $eno;}?>">
      <i class="far fa-id-card"></i>
      <br><br>

      <input class="form-control"type="email" name="email" placeholder="Enter email" autocomplete="off" required value="<?php if(isset($email)){ echo $email;}?>">
      <i class="far fa-envelope"></i><br><br>

      <input class="form-control"type="password" name="newpass" id="pswrd" placeholder="Enter new password" autocomplete="off" pattern=".{8,}" title=" Password must be 8 characters" required value="<?php if(isset($newpass)){ echo $newpass;}?>">
      <i class="fas fa-lock" onclick="show()"></i><br> <br>

      <input type="submit" name="submit" value="Change Password">
      
      <a href="facultylogin.php">Back to Login</a>

    </p>
    </form>
    </div>
  </div>
  </div>
  
</section>

</div>
</div>
<?php
include "footer2.php";
?>
<script>
    function show() {
      var pswrd=document.getElementById('pswrd');
      var icon=document.querySelector('.fas');
      if(pswrd.type=="password")
      {
        pswrd.type="text";
        icon.style.color = "#5c1769";
      }
      else
      {
          pswrd.type="password";
          icon.style.color="grey";
      }
    }
      
</script>

</body>
</html>