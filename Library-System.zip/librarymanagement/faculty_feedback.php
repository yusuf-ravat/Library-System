<!--Faculty-->
<?php
session_start();
if(!isset($_SESSION['faculty']))
{
  ?>
      <script type="text/javascript">
        alert("Please Login First..");
        window.location="facultylogin.php";
      </script>
  <?php
}
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Feedback</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}
.srch
{
  margin-left: 200px;
}

.sidenav {
  margin-top: 130px;
  height: 121.5%;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.wrapper
{
 padding: 10px;
 margin: -20px auto;
 width:900px;
 height: auto;
 position: relative;
 background-color: black;
 opacity: .8;
 color: white;
}

.header
{
 font-weight: bold;
 color: white;
 font-family: Century;
 background: #5c1769;
 border-bottom: 1px solid #5c1769;
 border-radius: 5px 5px 0 0;
}  
form{
 position: absolute;
 background:white;
 width: 94.8%;
 box-shadow: 0 16px 24px 2px 
 rgba(0,0,0,0.14), 0 20px 30px 5px 
 rgba(0,0,0,0.12), 0 8px 10px -5px 
 rgba(0,0,0,0.3);
 padding: 50px 20px 0 30px;
 box-sizing: border-box;
 border-radius: 0 0 5px 5px;
}
 form button[type="submit"]:hover{
background: #491254;
 transition: .5s;
 border: 1px solid black;
}
  
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <?php
  include "faculty_session.php";
  ?><br><br><br>

   <a href="index.php"><span class="glyphicon glyphicon-home"> Home</a>
    <a href="faculty_book.php"><span class="glyphicon glyphicon-search"> Book</a>
 <a href="faculty_issue.php"><span class="glyphicon glyphicon-check"> Issue Book</span></a>
 <a href="my_book_details_faculty.php"><span class="glyphicon glyphicon-list-alt"> My Book</span></a>
 <a href="faculty_profile.php"><span class="glyphicon glyphicon-user"> Profile</span></a>
  <a href="#"><span class="glyphicon glyphicon-briefcase"> About</span></a>
  <a href="#"><span class="glyphicon glyphicon-new-window"> Contact Us</span>
</a>
   <a href="faculty_logout.php"><span class="glyphicon glyphicon-log-out"> Logout</a>
</div>  
<header>
    <?php
    include "header.php";
    ?>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>


<script>
 <?php
    include "script.php";
    ?>
</script>
<section><br>
<body >
<div class="container">
<div class="row " style="margin-top: 50px">
<div class="col-md-6 col-md-offset-3 form-container">
<div class="header">
<h2 class="text-center"><b>Feedback</b></h2> <br></div>
                    
 <form  method="POST" action="">
 <p> Please provide your feedback below: </p>
 <p><b>How do you rate your overall experience?</b></p>
<label class="radio-inline">
      <input type="radio" name="experience" value="Bad">
  Bad 
</label>
<label class="radio-inline">
      <input type="radio" name="experience" value=" Average">
  Average  
</label> 
<label class="radio-inline">
    <input type="radio" name="experience" value="Good">
  Good 
</label> 
<label class="radio-inline">
    <input type="radio" name="experience" value="Excellent">
  Excellent
</label>
<br><br>
 <label> Comments:</label>
    <textarea class="form-control" type="textarea" name="comments" placeholder="Your Comments..." maxlength="6000" rows="7">
    </textarea><br>
<input style="background-color:#5c1769;" type="submit" name="submit" value="Post" class="btn btn-lg btn-warning btn-block" ><br>
</form>
</section>

<?php
 date_default_timezone_set("Asia/Kolkata");
$date = date('Y-m-d H:i:s');

     if(isset($_POST['submit']))
     {

        $comment=$_POST['comments'];
        $experience=$_POST['experience'];

        $query="INSERT INTO `comments` VALUES ('','$_SESSION[faculty]','$experience','$comment','$date')";
        $run=mysqli_query($db,$query);

        if($run){
        ?>
        <script type="text/javascript">
          alert("Feedback Post ");
        </script>
        <?php
      }
      else
      {
        ?>
        <script type="text/javascript">
          alert("Feedback not Post ");
        </script>
        <?php
      }
      } 
    ?>


 </div>
 </div>

<?php
include "footer2.php";
?>
 
</body>
</html>