<!--LIBRAIND ALL USER INFORMATION-->
<!DOCTYPE html>
<html>
<head>
<style>
.dropbtn {
  background-color: #5b285e;
  color: white;
  padding: 10px;
  font-size: 16px;
  border: 2px color:white;
  border-radius: 3px;
  cursor: pointer;

}

.dropdown {
  position: absolute;
  display: inline-block;
   margin-left: 360px;
   margin-top: 15px;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
  background-color: #5b285e;
  color: white;
}

.dropdown:hover .dropdown-content {
  display: block;
  padding: 2px;
}

.dropdown:hover .dropbtn {
  background-color: #5b285e;
  padding: 13px;
}
</style>
</head>
<body>

<h2></h2>
<div class="dropdown">
  <button class="dropbtn">Select Type</button>
  <div class="dropdown-content">
  <a href="student_info.php">Student Information</a>
  <a href="faculty_info.php">Faculty information</a>
  </div>
</div>

</body>
</html>
