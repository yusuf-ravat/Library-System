<!--STUDENT-->
<?php
session_start();
include("connection.php");
if(!isset($_SESSION['student']))
{
  ?>
      <script type="text/javascript">
         alert("Please Login First..");
        window.location="st_login.php";
      </script>
  <?php
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>My Book Details</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}
.srch
{
  margin-left: 200px;
}

.sidenav {
  margin-top: 130px;
  height: 121.5%;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
 .scroll
      {
        width: auto;
        height: 300px;
        overflow: auto;
      }
  
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
 <?php
  include "session.php";
  ?><br><br><br>
 <a href="index.php"><span class="glyphicon glyphicon-home"> Home</span></a>
 <a href="student_book.php"><span class="glyphicon glyphicon-search"> Book</a> 
 <a href="student_issue.php"><span class="glyphicon glyphicon-check"> Issue Book</span></a>
  <a href="feedback.php"><span class="glyphicon glyphicon-comment"> Feedback</span></a>  
  <a href="student_profile.php"><span class="glyphicon glyphicon-user"> Profile</span></a>
  <a href="#"><span class="glyphicon glyphicon-briefcase"> About</span></a>
  <a href="#"><span class="glyphicon glyphicon-new-window"> Contact Us</span>
</a>
   <a href="st_logout.php"><span class="glyphicon glyphicon-log-out"> Logout</a>
</div>
<header>
  <?php
  include "header.php";
  ?>
          </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>

<script>
 <?php
  include "script.php";
  ?>
</script><br><br><br><br>
<h2 style="font-family: Century; font-size: 35px;"><b> Return Book  Details</b></h2><br>
  <?php
echo "<div class =scroll>";
?>
  <?php
  
    $res=mysqli_query($db,"SELECT * from return_book  where seno='$_SESSION[student]' and status='Return'");
     if(mysqli_num_rows($res)==0)
          {
             ?>

    <script type="text/javascript">
      alert("Return Book Details Not Available! ")
      window.location="student_book.php"
    </script>
    <?php
}
else
{
    echo "<table class='table table-bordered table-hover' >";
  echo "<tr style='background-color: #5b285e; color:white;'>";
            //Table header
        echo "<th>"; echo "Enrollment"; echo"</th>";
        echo "<th>"; echo "Book Id"; echo"</th>";
        echo "<th>"; echo "Status"; echo"</th>";
        echo "<th>"; echo "Return Date"; echo"</th>";
  echo "</tr>";
    while ($row=mysqli_fetch_array($res))
     {
       echo "<tr>";

        echo "<td>";
           echo $row["seno"];
       echo "</td>";

       echo "<td>";
           echo $row["b_id"];
       echo "</td>";

       echo "<td>";
           echo $row["status"];
       echo "</td>";

       echo "<td>";
           echo $row["return_date"];
       echo "</td>";
       echo "</tr>";
     }
echo "</table>";
echo "</div>";
}
  ?>


<section>

 
  <?php
  
    ?>  

</section>
     </div>
  </div>
  </div>
    <?php
include "footer2.php";
?>
</body>
</html>