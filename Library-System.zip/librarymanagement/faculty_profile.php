<!--FACULTY-->
<?php
session_start();
if(!isset($_SESSION['faculty']))
{
  ?>
      <script type="text/javascript">
         alert("Please Login First..");
        window.location="facultylogin.php";
      </script>
  <?php
}
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
  <title>My Profile</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

 .srch
    {
      padding-left: 1000px;
    }
body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}

.sidenav {
  margin-top: 130px;
  height: 1016px;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.container
{
 margin: 0px auto;
  width: 500px;
 position: relative;
 color:white;
  border-radius:5px;
text-align: center;
background-color:#5b285e ; 
}
.profile
{
  margin: 0px auto;
  width: 500px;
 position: relative;
 color:black;
  border-radius:5px;
background-color:white ;
 box-shadow: 0 16px 24px 2px 
 rgba(0,0,0,0.14), 0 20px 30px 5px 
 rgba(0,0,0,0.12), 0 8px 10px -5px 
 rgba(0,0,0,0.3);
  padding: 10px 20px 2px 20px;
 border-radius: 0 0 5px 5px;
  box-sizing: border-box;
}

</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <?php
  include "faculty_session.php";
  ?><br><br><br>
  <a href="index.php"><span class="glyphicon glyphicon-home"> Home</a>
        <a href="faculty_book.php"><span class="glyphicon glyphicon-search"> Book</a>

 <a href="faculty_issue.php"><span class="glyphicon glyphicon-check"> Issue Book</span></a>
 <a href="my_book_details_faculty.php"><span class="glyphicon glyphicon-list-alt"> My Book</span></a>
 <a href="faculty_feedback.php"><span class="glyphicon glyphicon-comment"> Feedback</span>
  <a href="#"><span class="glyphicon glyphicon-briefcase"> About</span></a>
  <a href="#"><span class="glyphicon glyphicon-new-window"> Contact Us</span>
</a>
   <a href="faculty_logout.php"><span class="glyphicon glyphicon-log-out"> Logout</a>
</div>
<header>
   <?php
   include "header.php";
   ?>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>


<script>
 <?php
   include "script.php";
   ?>
</script><br><br><br><br><br><br>
<div class="container">
<h2 style="font-family: Century; font-size: 35px;"><b> My Profile</b></h2><br>
</div>
<section>
  <?php
          $q=mysqli_query($db,"SELECT * from faculty where f_id='$_SESSION[faculty]'");
          $row=mysqli_fetch_assoc($q);
          echo "<div class='profile'>";
          echo "<table class='table table-bordered table-hover' >";
          echo "<tr>";
                echo "<td>";
                      echo "<b>Name: </b>";
                echo "</td>";

                echo "<td>";
                      echo $row["faculty_name"];
                echo "</td>";
          echo "</tr>";

          echo "<tr>";
                echo "<td>";
                    echo "<b>Id: </b>";
                echo "</td>";

                echo "<td>";
                    echo $row["f_id"];
                echo "</td>";
          echo "</tr>";

          echo "<tr>";
                echo "<td>";
                    echo "<b>Email id: </b>";
                echo "</td>";

                echo "<td>";
                    echo $row["f_email"]."&nbsp&nbsp&nbsp<a href=''>Edit</>";
                echo "</td>";
          echo "</tr>";

          echo "<tr>";
                echo "<td>";
                      echo "<b>Mobile:</b>";
                echo "</td>";

                echo "<td>";
                        echo $row["f_mobile"]."&nbsp&nbsp&nbsp<a href=''>Edit</>";
                echo "</td>";
          echo "</tr>";

          echo "<tr>";
                echo "<td>";
                      echo "<b>Department: </b>";
                echo "</td>";

                echo "<td>";
                      echo $row["f_dept"];
                echo "</td>";
          echo "</tr>";

          echo "<tr>";
                echo "<td>";
                        echo "<b>Password: </b>";
                echo "</td>";

                echo "<td>";
                      echo "********";
                echo "</td>";
          echo "</tr>";

          echo "</table>";
echo "</div>";
  
    ?>  
</section>
     </div>
  </div>
  </div>
  <?php
include "footer2.php";
?>
</body>
</html>