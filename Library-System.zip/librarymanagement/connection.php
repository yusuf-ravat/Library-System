<?php
$db=mysqli_connect("localhost","root","","library system");
if(!$db)
{
die("Connection failed:".mysqli_connect_error());
}
?>