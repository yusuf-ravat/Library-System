<?php
    
    echo $nextDate = date("d-m-Y ", strtotime(" +20 day"));
?>
//echo $startDate = date('d-m-Y '); echo "<br/>";