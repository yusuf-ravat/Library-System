<!--LIBRARIAN FACULTY RETURN BOOK-->
<?php
session_start();
include "connection.php";

$id=$_GET["id"];
$fid=$_GET["fid"];
//$a=date("d-m-y");
//$res=mysqli_query($db,"UPDATE issue_book set returndate='$a' where id=$id");
$b_id="";
$faculty_id="";
$res=mysqli_query($db,"SELECT * from faculty_issue where b_id=$id AND faculty_id=$fid");

while ( $row=mysqli_fetch_array($res)) 
{
	$b_id=$row["b_id"];
	$faculty_id=$row["faculty_id"];

}
$d=date("Y-m-d");
mysqli_query($db,"UPDATE add_book set  avilable=avilable+1 where b_id='$id'");
mysqli_query($db,"UPDATE faculty_issue set status='Return',returndate='$d' where b_id='$id' AND faculty_id='$fid'");

mysqli_query($db,"INSERT INTO faculty_return (fa_id,b_id,status,return_date) SELECT 
faculty_id,b_id,status,returndate FROM faculty_issue WHERE status='Return';");
			
mysqli_query($db,"DELETE FROM faculty_issue WHERE status='Return'");
    ?>
    <script type="text/javascript">
      alert("Return Book Successfull");
      window.location="return_book_faculty.php";
    </script>
<?php