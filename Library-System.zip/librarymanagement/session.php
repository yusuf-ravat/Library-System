<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.sesion
		{
			color:white;
			font-family: Century;
			font-size: 17px;
			padding: 10px;
		}
	</style>
</head>
<body>

<?php
echo "<div class=sesion>";
$q=mysqli_query($db,"SELECT * from student where s_enroll='$_SESSION[student]'");

 $row=mysqli_fetch_assoc($q);
 
   echo "<b>Name:</b>&nbsp&nbsp"
                    .$row['first_name']."<br>";

   echo "<b>Enrollment:</b>&nbsp&nbsp"
                   .$row['s_enroll']."<br>";
echo "</div>";
  ?>
  </body>
</html>