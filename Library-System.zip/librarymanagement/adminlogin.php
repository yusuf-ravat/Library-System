<!--LIBRARIAN-->
<?php
session_start();
include ("connection.php");
?>
<?php
if(isset($_POST['submit']))
{
  $count=0;
        $id=$_POST['username'];
        $a_pass=$_POST['pass'];
        //$mdpass=md5($pass);
        //$a_pass=sha1($mdpass);
  $res=mysqli_query($db,"SELECT * FROM `admin` WHERE admin_name='$id' && pass='$a_pass';");
  $count=mysqli_num_rows($res);

  if($count==0)
  {
    $err="Login Invalid! Please check User id and Password";
  }
  else
  {
    $_SESSION["admin"]=$_POST["username"];

    ?>
    <script type="text/javascript">
      alert("login successful...");
      window.location="student_info.php";
    </script>
    <?php
  }
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!--Icon-->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">
	section
	{
		margin-top: -20px;
	}

body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
  /*background-color: rgb(0, 191,150);*/
}

.sidenav {
  margin-top: 130px;
  height: 827px;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
  margin-top: 2px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
 /* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #333;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  margin-left: 10px;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: black;}
/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {color: #f1f1f1;}



</style>

</head>
<body>
  <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a><br><br><br>
  <a href="index.php"><span class="glyphicon glyphicon-home"> Home</span></a><br>
  <a href="a_book.php"> <span class="glyphicon glyphicon-search"> Search Book</span></a><br>
  <div class="dropdown">
  <a style=" font-size:25px;" ><span class="glyphicon glyphicon-log-in"> Sign Up</span></a>
  <div class="dropdown-content">
     <a href="staffregister.php">Staff</a>
    <a href="facultyreg.php">Faculty</a>
    <a href="user_reg.php">Student</a>
  </div>
</div><br>
   <div class="dropdown">
  <a  style=" font-size:25px;"><span class="glyphicon glyphicon-user"> Sign In</span></a>
  <div class="dropdown-content">
    <a href="stafflogin.php">Staff</a>
    <a href="facultylogin.php">Faculty</a>
    <a href="st_login.php">Student</a>
  </div>
</div><br>
  <!--<a href="adminlogin.php"> <span class="glyphicon glyphicon-log-in"> Login</span></a>
  <a href="user_reg.php"> <span class="glyphicon glyphicon-user"> NewUser</span></a>
  -->
  <a href="#"><span class="glyphicon glyphicon-about"> About</span></a><br>
  <a href="#">Contact Us</a>
</div>
        <?php
        include "header.php";
        ?>
        <div id="main">
  
  <span style="font-size:30px;cursor:pointer; color:black;" onclick="openNav()">&#9776; Open</span>


<script>
 <?php
   include "script.php";
   ?>
</script>
 
<section>



	<div class="log_img">
	 <div class="box1">
 <div class="header">
Admin Sign in </div>
		<!--<h1 style="text-align: center; font-size: 25px;font-family: Algerian;">Admin Login</h1><br>-->
		<form name="login" action="" method="POST">
			
        <span class="error"><?php if(isset($err)){ echo $err;} ?></span><br><br>
			<input class="form-control"type="text" name="username" placeholder="Enter User Name" autocomplete="off" required value="<?php if(isset($id)){ echo $id;}?>">
      <i class="far fa-user"></i><br><br>

			<input class="form-control" type="password" name="pass" id="pswrd" placeholder="Enter Password" autocomplete="off" required  value="<?php if(isset($a_pass)){ echo $a_pass;}?>">
      <i class="fas fa-lock" onclick="show()"></i>
      <br><br>

			<input type="submit" name="submit" value="Sign In">
			
      <a  href="">Forgot Password?</a>
		</form>
    </div>
	</div>
	</div>
  
</section>

</div>
</biv>
<?php
include "footer2.php";
?>
<script>
  function show(){
   var pswrd = document.getElementById('pswrd');
   var icon = document.querySelector('.fas');
   if (pswrd.type === "password") {
    pswrd.type = "text";
    //pswrd.style.marginTop = "20px";
    icon.style.color = "#5c1769";
   }else{
    pswrd.type = "password";
    icon.style.color = "grey";
   }
  }
 </script>
</body>
</html>