<!--Student BOOK-->
<?php
session_start();
include("connection.php");

if(!isset($_SESSION['student']))
{
  ?>
      <script type="text/javascript">
         alert("Please Login First...");
        window.location="st_login.php";
      </script>
  <?php
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Search Book</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">

 .srch
    {
      padding-left: 1000px;
    }
body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}

.sidenav {
  margin-top: 130px;
  height: 1016px;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.scroll
      {
        width: auto;
        height: 800px;
        overflow: auto;
      }


</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <?php
  include "session.php";
  ?><br><br><br>
  <a href="index.php"><span class="glyphicon glyphicon-home"> Home</span></a>
 <a href="student_issue.php"><span class="glyphicon glyphicon-check"> Issue Book</span></a>  
  <a href="my_book_details_student.php"><span class="glyphicon glyphicon-list-alt"> My Book</span></a>
  <a href="feedback.php"><span class="glyphicon glyphicon-comment"> Feedback</span></a>  
  <a href="student_profile.php"><span class="glyphicon glyphicon-user"> Profile</span></a>
  <a href="#"><span class="glyphicon glyphicon-briefcase"> About</span></a>
  <a href="#"><span class="glyphicon glyphicon-new-window"> Contact Us</span>
</a>
   <a href="st_logout.php"><span class="glyphicon glyphicon-log-out"> Logout</a>
</div>
<header>
   <?php
   include "header.php";
   ?>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>
<script>
 <?php
   include "script.php";
   ?>
</script><br><br>
  <!--_____________search bar__________________-->
  <div class="srch">
    <form class="navbar-form" method="POST" name="form1">
      
        <input class="form-control" type="text" name="search" title="Search" placeholder="Search Book..." required>
        <button style="background-color:#5b285e; color: white;" type="submit" name="submit" class="btn btn-default">
        <span class="glyphicon glyphicon-search"></span>
        </button>
     
    </form>
  </div>
<!--_________________Request Book________-->
  <div class="srch">
    <form class="navbar-form" method="POST" name="form1">
      
        <input class="form-control" type="text" name="b_id" placeholder="Enter Book id..." required>
        <button style="background-color:#5b285e; color: white;;" type="submit" name="submit2" class="btn btn-default">Book Request 
        </button>
     
    </form>
  </div>
<section>

 <h2 style="font-family: Century; font-size: 35px;"><b>List of Books</b></h2><br>
  <div class="scroll">
  <?php
       if(isset($_POST['submit']))
       {
          $q=mysqli_query($db," SELECT * from add_book where b_name like '%$_POST[search]%' || b_author like '%$_POST[search]'");
          if(mysqli_num_rows($q)==0)
          {
            echo "Sorry! No Book Available Try  Again Sometime";
          }
          else
          {
         echo "<table class='table table-bordered table-hover' >";
      echo "<tr style='background-color: #5b285e; color:white;'>";
        //Table header
        
        echo "<th>"; echo "Book Id"; echo"</th>";
        echo "<th>"; echo "Book Name"; echo"</th>";
        echo "<th>"; echo "Author"; echo"</th>";
        echo "<th>"; echo "Publiched"; echo"</th>";
        echo "<th>"; echo "Edition"; echo"</th>";
        echo "<th>"; echo "Page"; echo"</th>";
        echo "<th>"; echo "Copy"; echo"</th>";
        echo "<th>"; echo "Available";echo"</th>";
        echo "<th>"; echo "Price"; echo"</th>";
        echo "<th>"; echo "Department"; echo"</th>";
        echo "<th>"; echo "Semester"; echo"</th>";
      echo "</tr>";

      while($row=mysqli_fetch_assoc($q))
      {
        echo "<tr>";
            echo"<td>"; echo $row['b_id']; echo "</td>";
            echo"<td>"; echo $row['b_name']; echo "</td>";
            echo"<td>"; echo $row['b_author']; echo "</td>";
            echo"<td>"; echo $row['b_pub']; echo "</td>";
            echo"<td>"; echo $row['b_edi']; echo "</td>";
            echo"<td>"; echo $row['b_page']; echo "</td>";
            echo"<td>"; echo $row['b_copy']; echo "</td>";
            echo"<td>"; echo $row['avilable']; echo "</td>";
            echo"<td>"; echo $row['b_price']; echo "</td>";
            echo"<td>"; echo $row['b_dept']; echo "</td>";
            echo"<td>"; echo $row['b_sem']; echo "</td>";

        echo "</tr>";
      }
    echo "</table>";
          }
       }
       /* button is not pressd.*/
       else
       { 
        $res=mysqli_query($db,"SELECT * FROM `add_book`;");

    echo "<table class='table table-bordered table-hover' >";
      echo "<tr style='background-color: #5b285e; color:white;'>";
        //Table header
        
        echo "<th>"; echo "Book Id"; echo"</th>";
        echo "<th>"; echo "Book Name"; echo"</th>";
        echo "<th>"; echo "Author"; echo"</th>";
        echo "<th>"; echo "Publiched"; echo"</th>";
        echo "<th>"; echo "Edition"; echo"</th>";
        echo "<th>"; echo "Page"; echo"</th>";
        echo "<th>"; echo "Copy"; echo"</th>";
        echo "<th>"; echo "Available";echo"</th>";
        echo "<th>"; echo "Price"; echo"</th>";
        echo "<th>"; echo "Department"; echo"</th>";
        echo "<th>"; echo "Semester";echo"</th>";


      echo "</tr>"; 

      while($row=mysqli_fetch_assoc($res))
      {
        echo "<tr>";

            echo"<td>"; echo $row['b_id']; echo "</td>";
            echo"<td>"; echo $row['b_name']; echo "</td>";
            echo"<td>"; echo $row['b_author']; echo "</td>";
            echo"<td>"; echo $row['b_pub']; echo "</td>";
            echo"<td>"; echo $row['b_edi']; echo "</td>";
            echo"<td>"; echo $row['b_page']; echo "</td>";
            echo"<td>"; echo $row['b_copy']; echo "</td>";
            echo"<td>"; echo $row['avilable']; echo "</td>";
            echo"<td>"; echo $row['b_price']; echo "</td>";
            echo"<td>"; echo $row['b_dept']; echo "</td>";
            echo"<td>"; echo $row['b_sem']; echo "</td>";
  
        echo "</tr>";
      }
    echo "</table>"; 
       } 
    $date=date("Y-m-d");
   $reserve_end_date= date('Y-m-d', strtotime($date. ' + 2 days'));

if(isset($_POST['submit2']))
{
    if(isset($_SESSION['student']))
    {

 $res2=mysqli_query($db,"SELECT b_id from issue_book where b_id='$_POST[b_id]'");
        if(mysqli_num_rows($res2)>0)
        {
          ?>
            <script type="text/javascript">
              alert("Already Book Issued");
               window.location="student_book.php";
            </script>
            <?php
            return 0;
        }

    $res1=mysqli_query($db,"SELECT b_id from add_book where b_id='$_POST[b_id]'");
        if(mysqli_num_rows($res1)==0)
        {
          ?>
            <script type="text/javascript">
              alert("Books Are Not Registered");
               window.location="student_book.php";
            </script>
            <?php
            return 0;
        }
       $res=mysqli_query($db,"SELECT avilable,b_id from add_book where avilable=0 and  b_id='$_POST[b_id]'");
       
       if(mysqli_num_rows($res)==0)
          {
             mysqli_query($db,"INSERT INTO issue_book values ('','$_SESSION[student]','$_POST[b_id]','Reserve','$reserve_end_date','','')");

            mysqli_query($db,"UPDATE add_book set  avilable=avilable-1 where b_id='$_POST[b_id]'");

             ?>
            <script type="text/javascript">
              alert("Your Book Is Reserved");
              window.location="student_issue.php";
            </script>
            <?php
          }
          else
          {
             ?>
            <script type="text/javascript">
              alert("Book Is Not Available ")
              window.location="student_book.php";
            </script>
            <?php
            
           }
     }
}
?>
</section>
     </div>
  </div>
  </div>
  <?php
include ("footer2.php");
?>
</body>
</html>