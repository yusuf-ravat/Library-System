<!DOCTYPE html>
<html>
<head>

</head>
<body>
<header>
   <img src="download.png" height="120px" width="120px" class="img">
   <p class="h" style= "font-family: Algerian; margin-left: 200px; margin-top: -85px; font-size: 37px;"><b>Library Management System Government Polytechnic Waghai</b></p>
      </header>
</body>
</html>