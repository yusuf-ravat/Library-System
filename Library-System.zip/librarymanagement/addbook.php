<!--LIBRARIAN-->
<?php
session_start();
if(!isset($_SESSION['admin']))
{
  ?>
      <script type="text/javascript">
         alert("Please Login First..");
        window.location="adminlogin.php";
      </script>
  <?php
}
include("connection.php");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Addbook</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">


body {
  font-family: "Lato", sans-serif;
  transition: background-color .5s;
}

.sidenav {
  margin-top: 130px;
  height: 844px;
  width: 0;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
  background-color: #5b285e;
  border-radius: 5px;
  padding: 10px;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.form-control
{
  margin-left: -5px;
}
.note
{
 font-size: 28px;
 font-weight: bold;
 color: white;
 font-family: Century; 
 text-align: center;
 padding: 25px 0 30px 25px;
 background: #5c1769;
 border-bottom: 1px solid #5c1769;
 border-radius: 5px 5px 0 0;
}
.form-content
{
    padding: 5%;
    margin-bottom: 2%;
    border: 1px solid #5c1769;
    border-radius: 0 0 5px 5px;
}

.btnSubmit{ 
    border:none;
    border-radius:0.5rem;
    padding: 1.5%;
    width: 100%;
    cursor: pointer;
    background: #5c1769;
    color: #fff;
}
.btnSubmit:hover{
 background: #491254;
 transition: .5s;
 border: 1px solid black;
}
</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <?php
  echo "<h3 style='color:white;font-family:Century;'>Welcome &nbsp$_SESSION[admin]</h3s>";
  ?><br><br><br>
  <a href="index.php"><span class="glyphicon glyphicon-home"> Home</span></a>

  <a href="student_info.php"><span class="glyphicon glyphicon-user"> User Approve</span></a> 

  <a href="a_book.php"><span class="glyphicon glyphicon-search"> Book</span></a>

  <a href="student_book_request.php"><span class="glyphicon glyphicon-registration-mark"> Book Request</span></a>

  <a href="return_book_student.php"><span class="glyphicon glyphicon-repeat"> Return Book</span></a>

  <a href="student_issue_book_details.php"><span class="glyphicon glyphicon-check">  Issue Details</span></a>

  <a href="user_book_details.php"><span class="glyphicon glyphicon-list-alt"> Book Details</span></a>

  <a href="admin_feedback.php"><span class="glyphicon glyphicon-thumbs-up"> Review</span></a>

    <a href="#"><span class="glyphicon glyphicon-briefcase"> About</span></a>

  <a href="#"> 
<span class="glyphicon glyphicon-new-window"> Contact Us</span></a>

  <a href="logout.php"><span class="glyphicon glyphicon-log-out"> Logout</span></a>
</div>
<header>
    <?php
    include "header.php";
    ?>
      </header>
  <div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Open</span>


<script>
 <?php
    include "script.php";
    ?>
</script><br><br><br>
<section>
  <div class="container register-form">
            <div class="form">
                <div class="note">
                    <p class="text-center">Add Book</p>
                </div>

                <div class="form-content">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
   <!-- <h1 style="text-align: center; font-size: 25px; font-family: Algerian;">Add Book</h1><br>-->
    <form name="register" action=" " method="POST">
      <input class="form-control" type="text" name="id" placeholder="Enter Book id" autocomplete="off" required><br>
    </div>
    <div class="form-group">

      <input class="form-control" type="text" name="name" placeholder="Enter Book Name" autocomplete="off" required><br>   
    </div>
    </div>
    <div class="col-md-6">
    <div class="form-group">

      <input class="form-control" type="text" name="author" placeholder="Enter Book Author" autocomplete="off" required><br>
      </div>
       <div class="form-group">

      <input class="form-control" type="text" name="pub" placeholder="Enter Book Published" autocomplete="off" required><br>
    </div>
    </div>
    <div class="col-md-6">
    <div class="form-group">
      <input class="form-control" type="text" name="edi" placeholder="Enter Book Edition" autocomplete="off" required><br>
       </div>
       <div class="form-group">

            <input class="form-control" type="text" name="page" placeholder="Enter Book Page" autocomplete="off" required><br>
    </div>
    </div>
    <div class="col-md-6">
    <div class="form-group">
      <input class="form-control" type="text" name="copy" placeholder="Enter Book Copy" autocomplete="off" required><br>
 </div>
       <div class="form-group">

       <input class="form-control" type="text" name="avilable" placeholder="Enter Book Avilable Copy" autocomplete="off" required><br>
</div>
    </div>
    <div class="col-md-6">
    <div class="form-group">
      <input class="form-control" type="text" name="price" placeholder="Enter Book Price" autocomplete="off" required><br>
 </div>
       <div class="form-group">
       <select name="dept" class="form-control"   required><br>
        <option disabled selected value>Select Department</option>
        <option >Computer</option>
        <option >Civil</option>
        <option >Mechanical</option>
       </select>
</div>
    </div>
    <div class="col-md-6">
    <div class="form-group">
         <select name="sem" class="form-control"  required><br>
       <option disabled selected value >Select Semester</option>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
        <option>6</option>
       </select><br>
       </div>
       <div class="form-group">
    </div>
                       
                    <input type="submit" name="submit1" class="btnSubmit" value="Add Book">
                    </div>
    </div>
  

                </div>
            </div>
        </div>
    </form> 
  </div>
  </div>
  <?php
if(isset($_POST['submit1']))
{
      $id=$_POST['id'];
      $bname=$_POST['name'];
      $bauthor=$_POST['author'];
      $pbls=$_POST['pub'];
      $edi=$_POST['edi'];
      $page=$_POST['page'];
      $copy=$_POST['copy'];
      $avilable=$_POST['avilable'];
      $price=$_POST['price'];

      mysqli_query($db,"INSERT INTO add_book VALUES('',$id','$bname','$bauthor','$pbls','$edi','$page','$copy','$avilable','$price','$_POST[dept]','$_POST[sem]')");
      ?>
      <script type="text/javascript">
        alret("Book Inserted Successful...");
        window.location="addbook.php";

      </script>
      <?php 
}
?>
</section>


  </div>
</div>
<?php
include "footer2.php";
?>

</div>
</body>
</html>