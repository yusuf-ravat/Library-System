<!--LIBRARIAN DELETE BOOK-->
<?php
session_start();
include "connection.php";

$id=$_GET["del"];

      mysqli_query($db,"DELETE FROM add_book where b_id='$id'");

         ?>
    <script type="text/javascript">
      alert("Delete Book Successfull");
      window.location="a_book.php";
    </script>
    <?php

 ?>